{
 "cells": [
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "abc081d1-6251-417a-83a1-33870669be20",
   "metadata": {},
   "outputs": [],
   "source": [
    "from flask import Flask, render_template, request\n",
    "import pandas as pd\n",
    "import xgboost as xgb\n",
    "import pickle\n",
    "\n",
    "app = Flask(__name__)\n",
    "\n",
    "# Load the trained model\n",
    "loaded_model = xgb.XGBClassifier()\n",
    "loaded_model.load_model('xgboost_model.pkl')\n",
    "\n",
    "# Function to preprocess user input, make predictions, and map predicted labels to emotions\n",
    "def make_prediction_and_map_emotion(user_input):\n",
    "    # Load the DataFrame containing the column names used for training\n",
    "    df = pd.read_csv(\"mental-state.csv\")\n",
    "    # Assuming 'Label' is the target variable\n",
    "    X_columns = df.drop('Label', axis=1).columns\n",
    "    \n",
    "    # Convert user input to a DataFrame with the same column names as your original dataset\n",
    "    input_df = pd.DataFrame(user_input, index=[0])\n",
    "    \n",
    "    # Make sure the columns are in the same order as the columns used for training\n",
    "    input_df = input_df[X_columns]\n",
    "    \n",
    "    # Make prediction\n",
    "    prediction = loaded_model.predict(input_df)\n",
    "    \n",
    "    # Map predicted labels to emotions\n",
    "    emotion_map = {\n",
    "        0: 'happy',\n",
    "        1: 'neutral',\n",
    "        2: 'sad'\n",
    "    }\n",
    "    predicted_emotion = emotion_map[prediction[0]]\n",
    "    \n",
    "    return predicted_emotion\n",
    "\n",
    "@app.route('/')\n",
    "def home():\n",
    "    return render_template('index.html')\n",
    "\n",
    "@app.route('/predict', methods=['POST'])\n",
    "def predict():\n",
    "    user_input = request.form.to_dict()\n",
    "    predicted_emotion = make_prediction_and_map_emotion(user_input)\n",
    "    return render_template('result.html', emotion=predicted_emotion)\n",
    "\n",
    "if __name__ == '__main__':\n",
    "    app.run(debug=True)\n"
   ]
  }
 ],
 "metadata": {
  "kernelspec": {
   "display_name": "Python 3 (ipykernel)",
   "language": "python",
   "name": "python3"
  },
  "language_info": {
   "codemirror_mode": {
    "name": "ipython",
    "version": 3
   },
   "file_extension": ".py",
   "mimetype": "text/x-python",
   "name": "python",
   "nbconvert_exporter": "python",
   "pygments_lexer": "ipython3",
   "version": "3.8.0"
  }
 },
 "nbformat": 4,
 "nbformat_minor": 5
}
