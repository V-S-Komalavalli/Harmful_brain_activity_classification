from flask import Flask, render_template, request
import pandas as pd
import xgboost as xgb

app = Flask(__name__)

# Load the trained model
loaded_model = xgb.XGBClassifier()
loaded_model.load_model('xgboost_model.pkl')

# Function to preprocess user input, make predictions, and map predicted labels to emotions
def make_prediction_and_map_emotion(user_input):
    # Load the DataFrame containing the column names used for training
    df = pd.read_csv("data.csv")
    # Assuming 'Label' is the target variable
    X_columns = df.drop('Label', axis=1).columns

    # Convert user input to a DataFrame with the same column names as your original dataset
    input_df = pd.DataFrame(user_input, index=[0])

    # Make sure the columns are in the same order as the columns used for training
    input_df = input_df[X_columns]

    # Make prediction
    prediction = loaded_model.predict(input_df)

    # Map predicted labels to emotions and treatment information (DISCLAIMER)
    emotion_map = {
        0: {
            'label': 'Seizure',
            'treatment_info': (
                "**Disclaimer:** I cannot provide specific medical advice. If you suspect "
                "a seizure, please seek immediate medical attention by calling emergency "
                "services or going to the nearest emergency department."
            )
        },
        1: {
            'label': 'Generalized periodic discharges (GPD)',
            'treatment_info': (
                "**Disclaimer:** I cannot provide specific medical advice. GPD treatment "
                "depends on the underlying cause. Please consult a neurologist for a proper "
                "diagnosis and treatment plan."
            )
        },
        2: {
            'label': 'Lateralized rhythmic delta activity (LRDA)',
            'treatment_info': (
                "**Disclaimer:** I cannot provide specific medical advice. LRDA treatment "
                "depends on the underlying cause. Please consult a neurologist for a proper "
                "diagnosis and treatment plan."
            )
        }
    }

    predicted_label = emotion_map[prediction[0]]['label']
    predicted_emotion = emotion_map[prediction[0]]['treatment_info']

    return predicted_label, predicted_emotion

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    user_input = {
        'lag1_mean_0': float(request.form['lag1_mean_0']),
        'lag1_mean_1': float(request.form['lag1_mean_1']),
        'lag1_mean_2': float(request.form['lag1_mean_2']),
        'lag1_mean_3': float(request.form['lag1_mean_3']),
        'lag1_mean_d_h2h1_0': float(request.form['lag1_mean_d_h2h1_0']),
        'lag1_mean_d_h2h1_1': float(request.form['lag1_mean_d_h2h1_1']),
        'lag1_mean_d_h2h1_2': float(request.form['lag1_mean_d_h2h1_2']),
        'lag1_mean_d_h2h1_3': float(request.form['lag1_mean_d_h2h1_3']),
        'lag1_mean_q1_0': float(request.form['lag1_mean_q1_0']),
        'lag1_mean_q1_1': float(request.request.form['lag1_mean_q1_1'])
    }
    if all(value == 0 for value in user_input.values()):
        return "Please enter valid input data."
    predicted_label, predicted_emotion = make_prediction_and_map_emotion(user_input)

    return render_template('result.html', label=predicted_label, emotion=predicted_emotion)

if __name__ == '__main__':
    app.run(debug=True)
